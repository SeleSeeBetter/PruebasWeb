README - COMPRA DE ENTRADAS
Este trabajo documenta el proceso de desarrollo de una plataforma web para la compra de entradas, creada desde cero. 
La tecnología utilizada incluye HTML para la estructura, CSS para el diseño visual y JavaScript para la interactividad. 
El objetivo principal es ofrecer una web funcional, intuitiva y atractiva, facilitando la navegación y el proceso de compra de los usuarios.
En este proyecto se verá desde la organización del código hasta la implementación de los formularios de compra, la validación 
de datos y la mejora del rendimiento y la experiencia del usuario. Para llevar a cabo este proyecto, se ha utilizado el editor de código Visual Studio Code.